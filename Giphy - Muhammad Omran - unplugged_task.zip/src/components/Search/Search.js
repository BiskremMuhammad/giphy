import React, { Component } from 'react';

import styles from './Search.css';

class Search extends Component{
	render() {
		return (
			<section className={styles.SearchPage}>
			</section>
		);
	}
}

export default Search;